"use client";
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Cpu,
  Cloud,
  Workflow,
  Code2,
  Database,
  Share2,
  Briefcase,
  BadgeCheck,
  Zap,
  Check,
  Activity,
  LogIn,
  Unlock,
  ShieldCheck,
  Shuffle,
  Lock,
  FileSignature,
  Server,
  PenLine,
  Route,
  ArrowRight,
  Send,
  Cable,
} from "lucide-react";
import type { ComponentType } from "react";

import Container from "@/components/ui/Container";
import { personal } from "@/data/personal";

const about = personal.about;

/* Map data-file icon keys -> components (keeps personal.ts plain data) */
type IconType = ComponentType<{ size?: number; className?: string }>;
const iconMap: Record<string, IconType> = {
  cpu: Cpu,
  cloud: Cloud,
  workflow: Workflow,
  code: Code2,
  database: Database,
  share: Share2,
  briefcase: Briefcase,
  badge: BadgeCheck,
  zap: Zap,
  // iFlow step icons
  login: LogIn,
  decrypt: Unlock,
  verify: ShieldCheck,
  map: Shuffle,
  encrypt: Lock,
  sign: FileSignature,
  receiver: Server,
  modify: PenLine,
  route: Route,
  partner: Send,
  sftp: Server,
  adapter: Cable,
  s4hana: Database,
};

const reveal = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-80px" },
};

/* Small mono section tag, e.g. "// 01 · profile" */
function Tag({ index, label }: { index: string; label: string }) {
  return (
    <p className="font-mono text-xs tracking-wide text-slate-500">
      <span className="text-cyan-400">// {index}</span> · {label}
    </p>
  );
}

/* Counts up from 0 to `to` the first time it scrolls into view */
function CountUp({ to, suffix = "" }: { to: number; suffix?: string }) {
  const [value, setValue] = useState(0);
  const started = useRef(false);

  return (
    <motion.span
      onViewportEnter={() => {
        if (started.current) return;
        started.current = true;
        const duration = 900;
        const start = performance.now();
        const tick = (now: number) => {
          const p = Math.min((now - start) / duration, 1);
          setValue(Math.round(p * to));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      }}
      viewport={{ once: true }}
    >
      {value}
      {suffix}
    </motion.span>
  );
}

/* Horizontal iFlow with two clearly different motion styles:
   - "step":   ONE node lights and marches left→right; arrows fill behind it.
   - "stream": every node stays lit and a scanning light-beam sweeps across
               the whole pipeline while the arrows pulse — a continuous flow. */
function FlowStrip({
  steps,
  variant = "step",
  interval = 900,
}: {
  steps: { icon: string; title: string; sub: string }[];
  variant?: string;
  interval?: number;
}) {
  const isStream = variant === "stream";
  const [active, setActive] = useState(0);

  useEffect(() => {
    if (isStream) return; // stream mode has no discrete active step
    const id = setInterval(
      () => setActive((a) => (a + 1) % steps.length),
      interval
    );
    return () => clearInterval(id);
  }, [steps.length, interval, isStream]);

  const row = (
    <div className="flex flex-col gap-3 md:flex-row md:items-center">
      {steps.map(({ icon, title, sub }, i) => {
        const Icon = iconMap[icon] ?? Cpu;
        const isActive = !isStream && i === active;
        // In stream mode every node reads as "lit"; in step mode only active.
        const lit = isStream || isActive;

        return (
          <div
            key={title}
            className="flex flex-1 items-center gap-3 md:flex-col md:gap-0"
          >
            {/* Node card */}
            <div
              className={`w-full rounded-2xl border p-4 text-center transition-all duration-500 ${
                isActive
                  ? "scale-105 border-cyan-400/70 bg-cyan-500/[0.07] shadow-[0_0_28px_rgba(34,211,238,0.22)]"
                  : isStream
                    ? "border-cyan-400/25 bg-slate-950/60"
                    : "border-white/5 bg-slate-950/60"
              }`}
            >
              <span
                className={`mx-auto flex h-11 w-11 items-center justify-center rounded-xl border transition-colors duration-500 ${
                  lit
                    ? "border-cyan-400/50 bg-cyan-500/20 text-cyan-300"
                    : "border-cyan-400/20 bg-cyan-500/10 text-cyan-400"
                }`}
              >
                <Icon size={20} />
              </span>
              <p className="mt-3 text-sm font-semibold text-white">{title}</p>
              <p className="mt-1 font-mono text-[10px] text-slate-500">{sub}</p>
            </div>

            {/* Connector */}
            {i < steps.length - 1 &&
              (isStream ? (
                <motion.div
                  animate={{ opacity: [0.15, 1, 0.15] }}
                  transition={{
                    duration: 1.3,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: i * 0.16,
                  }}
                  className="shrink-0 rotate-90 text-cyan-400 md:rotate-0"
                >
                  <ArrowRight size={18} />
                </motion.div>
              ) : (
                <ArrowRight
                  size={18}
                  className={`shrink-0 rotate-90 transition-colors duration-500 md:rotate-0 ${
                    i < active ? "text-cyan-400" : "text-cyan-400/25"
                  }`}
                />
              ))}
          </div>
        );
      })}
    </div>
  );

  // Step mode: plain row. Stream mode: wrap with a sweeping scanner beam.
  if (!isStream) return <div className="mt-6">{row}</div>;

  return (
    <div className="relative mt-6 overflow-hidden rounded-2xl">
      <div className="relative z-10">{row}</div>
      <motion.div
        aria-hidden
        animate={{ x: ["-40%", "140%"] }}
        transition={{ duration: 2.8, repeat: Infinity, ease: "linear" }}
        className="pointer-events-none absolute inset-y-0 z-20 w-28 -skew-x-12 bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent"
      />
    </div>
  );
}

/* Cycling "message processed" feed line */
function LiveFeed({ items }: { items: string[] }) {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setI((x) => (x + 1) % items.length), 1800);
    return () => clearInterval(id);
  }, [items.length]);

  return (
    <div className="mt-5 flex h-6 items-center overflow-hidden rounded-lg border border-white/5 bg-slate-950/60 px-3">
      <AnimatePresence mode="wait">
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.35 }}
          className="flex w-full items-center gap-2 font-mono text-[11px]"
        >
          <span className="text-cyan-400">▸</span>
          <span className="text-slate-300">{items[i]}</span>
          <span className="ml-auto flex items-center gap-1 text-emerald-400">
            <Check size={11} /> processed
          </span>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden bg-[#030712] py-28">
      {/* Glows */}
      <div className="absolute -left-40 top-20 h-[500px] w-[500px] rounded-full bg-cyan-500/10 blur-[160px]" />
      <div className="absolute -right-40 bottom-0 h-[500px] w-[500px] rounded-full bg-blue-500/10 blur-[160px]" />

      <Container>
        {/* Header — left aligned with accent bar */}
        <motion.div {...reveal} transition={{ duration: 0.6 }} className="max-w-2xl">
          <div className="flex items-center gap-4">
            <span className="h-8 w-1 rounded-full bg-cyan-400" />
            <p className="font-mono text-sm tracking-wide text-cyan-400">
              {about.eyebrow}
            </p>
          </div>
          <h2 className="mt-6 text-4xl font-black leading-tight text-white md:text-5xl">
            {about.title.lead}{" "}
            <span className="bg-gradient-to-r from-cyan-300 to-sky-500 bg-clip-text text-transparent">
              {about.title.accent}
            </span>
          </h2>
        </motion.div>

        {/* Row 1 — Who I am + side cards */}
        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {/* Who I am */}
          <motion.div
            {...reveal}
            transition={{ duration: 0.6 }}
            className="relative rounded-3xl border border-white/5 bg-slate-900/40 p-8 backdrop-blur lg:col-span-2"
          >
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-500/10 text-cyan-400">
                  <Code2 size={20} />
                </span>
                <h3 className="text-xl font-bold text-white">Who I am</h3>
              </div>
              <Tag index="01" label="profile" />
            </div>

            <p className="text-base leading-8 text-slate-400">{about.bio}</p>

            {/* Focus areas */}
            <div className="mt-8 flex flex-wrap gap-3">
              {about.focusAreas.map(({ icon, label }) => {
                const Icon = iconMap[icon] ?? Cpu;
                return (
                  <span
                    key={label}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/5 bg-slate-950/60 px-4 py-2 text-sm text-slate-300 transition-colors hover:border-cyan-400/40 hover:text-cyan-300"
                  >
                    <Icon size={16} className="text-cyan-400" />
                    {label}
                  </span>
                );
              })}
            </div>

            {/* Strengths */}
            <p className="mt-8 text-xs font-semibold uppercase tracking-[0.25em] text-slate-500">
              Strengths
            </p>
            <div className="mt-4 flex flex-wrap gap-2.5">
              {about.strengths.map((s) => (
                <span
                  key={s}
                  className="inline-flex items-center gap-2 rounded-full border border-cyan-400/15 bg-cyan-500/5 px-3.5 py-1.5 text-sm text-slate-300"
                >
                  <Check size={14} className="text-cyan-400" />
                  {s}
                </span>
              ))}
            </div>
          </motion.div>

          {/* Side cards */}
          <motion.div
            {...reveal}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="flex flex-col gap-6"
          >
            {/* Currently at */}
            <div className="rounded-3xl border border-white/5 bg-slate-900/40 p-6 backdrop-blur">
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-slate-500">
                Currently at
              </p>
              <div className="mt-4 flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-500/10 text-cyan-400">
                  <Briefcase size={20} />
                </span>
                <div>
                  <p className="font-semibold text-white">
                    {about.currentRole.company}
                  </p>
                  <p className="text-sm text-slate-400">
                    {about.currentRole.role} · Since {about.currentRole.since}
                  </p>
                </div>
              </div>
            </div>

            {/* Certifications */}
            <div className="rounded-3xl border border-white/5 bg-slate-900/40 p-6 backdrop-blur">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-500/10 text-cyan-400">
                  <BadgeCheck size={20} />
                </span>
                <div>
                  <p className="text-3xl font-black text-cyan-400">
                    <CountUp to={about.certifications.count} />
                  </p>
                  <p className="text-sm text-slate-400">
                    {about.certifications.label}
                  </p>
                </div>
              </div>
            </div>

            {/* Specialty */}
            <div className="relative overflow-hidden rounded-3xl border border-cyan-400/20 bg-gradient-to-br from-cyan-500/10 to-transparent p-6 backdrop-blur">
              <motion.div
                aria-hidden
                animate={{ x: ["-120%", "220%"] }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  repeatDelay: 1.2,
                }}
                className="pointer-events-none absolute inset-y-0 w-1/3 -skew-x-12 bg-gradient-to-r from-transparent via-cyan-400/15 to-transparent"
              />
              <div className="relative flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-cyan-400/30 bg-cyan-500/15 text-cyan-300">
                  <Zap size={20} />
                </span>
                <div>
                  <p className="text-lg font-bold text-white">
                    {about.specialty.title}
                  </p>
                  <p className="text-sm text-cyan-300/80">
                    {about.specialty.subtitle}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Row 2 — Integration Monitor (unique centerpiece) */}
        <motion.div
          {...reveal}
          transition={{ duration: 0.6 }}
          className="relative mt-6 overflow-hidden rounded-3xl border border-white/5 bg-slate-900/40 p-8 backdrop-blur"
        >
          {/* Corner ticks */}
          <span className="pointer-events-none absolute left-4 top-4 h-3 w-3 border-l border-t border-cyan-400/30" />
          <span className="pointer-events-none absolute right-4 top-4 h-3 w-3 border-r border-t border-cyan-400/30" />
          <span className="pointer-events-none absolute bottom-4 left-4 h-3 w-3 border-b border-l border-cyan-400/30" />
          <span className="pointer-events-none absolute bottom-4 right-4 h-3 w-3 border-b border-r border-cyan-400/30" />

          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-500/10 text-cyan-400">
                <Activity size={20} />
              </span>
              <div>
                <Tag index="02" label="monitor" />
                <h3 className="mt-1 text-2xl font-bold text-white">
                  Cloud Integration Architecture
                </h3>
              </div>
            </div>
            <span className="inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-500/5 px-4 py-1.5 text-sm text-cyan-300">
              <span className="h-2 w-2 animate-pulse rounded-full bg-cyan-400" />
              Streaming
            </span>
          </div>

          {/* iFlows — two cards, each with its own animation */}
          <div className="mt-8 flex flex-col gap-6">
            {about.monitor.flows.map((flow, idx) => (
              <div
                key={flow.title}
                className="rounded-2xl border border-white/5 bg-slate-950/50 p-6"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold text-white">
                    {flow.title}
                  </h4>
                  <p className="font-mono text-[11px] text-emerald-400">
                    ● online
                  </p>
                </div>
                <FlowStrip
                  steps={flow.steps}
                  variant={flow.animation}
                  interval={900 + idx * 150}
                />
              </div>
            ))}
          </div>

          {/* Live feed */}
          <div className="mt-6">
            <LiveFeed items={about.monitor.feed} />
          </div>
        </motion.div>

        {/* Row 3 — Highlights */}
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {about.highlights.map(({ icon, stat, text }, i) => {
            const Icon = iconMap[icon] ?? Workflow;
            return (
              <motion.div
                key={stat}
                {...reveal}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="rounded-3xl border border-white/5 bg-slate-900/40 p-6 backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:border-cyan-400/40"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-500/10 text-cyan-400">
                  <Icon size={20} />
                </span>
                <p className="mt-4 text-lg font-bold text-white">{stat}</p>
                <p className="mt-2 text-sm leading-6 text-slate-400">{text}</p>
              </motion.div>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
