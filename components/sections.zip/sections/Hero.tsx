"use client";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Download } from "lucide-react";

import Container from "@/components/ui/Container";
import Button from "@/components/shared/Button";
import { personal } from "@/data/personal";

/* ------------------------------------------------------------------ */
/*  Typing subtitle — cycles through skills with a type/delete effect  */
/* ------------------------------------------------------------------ */
const typingWords = [
  "SAP Cloud Integration",
  "SAP Process Orchestration",
  "API Management",
];

function TypingText() {
  const [wordIndex, setWordIndex] = useState(0);
  const [len, setLen] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = typingWords[wordIndex % typingWords.length];
    let delay = deleting ? 45 : 85;
    if (!deleting && len === word.length) delay = 1400;
    if (deleting && len === 0) delay = 350;

    const id = setTimeout(() => {
      if (!deleting && len < word.length) setLen(len + 1);
      else if (!deleting && len === word.length) setDeleting(true);
      else if (deleting && len > 0) setLen(len - 1);
      else {
        setDeleting(false);
        setWordIndex((w) => w + 1);
      }
    }, delay);

    return () => clearTimeout(id);
  }, [len, deleting, wordIndex]);

  const word = typingWords[wordIndex % typingWords.length];

  return (
    <span className="font-mono text-lg text-cyan-400 md:text-xl">
      <span className="text-slate-500">&gt; </span>
      {word.slice(0, len)}
      <span className="ml-0.5 inline-block h-5 w-[2px] translate-y-1 animate-pulse bg-cyan-400" />
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Code terminal — types itself out with a trailing cursor            */
/* ------------------------------------------------------------------ */
type Seg = { t: string; c?: string };
const codeLines: Seg[][] = [
  [
    { t: "import", c: "text-fuchsia-400" },
    { t: " com.sap.gateway.ip.core.customdev.util.", c: "text-slate-400" },
    { t: "Message", c: "text-emerald-300" },
  ],
  [
    { t: "import", c: "text-fuchsia-400" },
    { t: " groovy.json.", c: "text-slate-400" },
    { t: "JsonSlurper", c: "text-emerald-300" },
  ],
  [],
  [
    { t: "def", c: "text-fuchsia-400" },
    { t: " Message", c: "text-emerald-300" },
    { t: " processData", c: "text-yellow-300" },
    { t: "(", c: "text-slate-500" },
    { t: "Message", c: "text-emerald-300" },
    { t: " message", c: "text-slate-200" },
    { t: ") {", c: "text-slate-500" },
  ],
  [
    { t: "  def", c: "text-fuchsia-400" },
    { t: " body ", c: "text-slate-200" },
    { t: "= ", c: "text-slate-500" },
    { t: "message", c: "text-slate-200" },
    { t: ".getBody(", c: "text-cyan-300" },
    { t: "String", c: "text-emerald-300" },
    { t: ")", c: "text-cyan-300" },
  ],
  [
    { t: "  def", c: "text-fuchsia-400" },
    { t: " order ", c: "text-slate-200" },
    { t: "= ", c: "text-slate-500" },
    { t: "new", c: "text-fuchsia-400" },
    { t: " JsonSlurper", c: "text-emerald-300" },
    { t: "().parseText(", c: "text-cyan-300" },
    { t: "body", c: "text-slate-200" },
    { t: ")", c: "text-cyan-300" },
  ],
  [],
  [
    { t: "  message", c: "text-slate-200" },
    { t: ".setProperty(", c: "text-cyan-300" },
    { t: '"OrderId"', c: "text-amber-300" },
    { t: ", order.id)", c: "text-slate-300" },
  ],
  [
    { t: "  message", c: "text-slate-200" },
    { t: ".setHeader(", c: "text-cyan-300" },
    { t: '"MessageType"', c: "text-amber-300" },
    { t: ", ", c: "text-slate-500" },
    { t: '"OrderRequest"', c: "text-amber-300" },
    { t: ")", c: "text-cyan-300" },
  ],
  [],
  [
    { t: "  return", c: "text-fuchsia-400" },
    { t: " message", c: "text-slate-200" },
  ],
  [{ t: "}", c: "text-slate-500" }],
];

function CodeTerminal() {
  const { lineStarts, lineLens, total } = useMemo(() => {
    const lens = codeLines.map((l) => l.reduce((s, seg) => s + seg.t.length, 0));
    const starts: number[] = [];
    let acc = 0;
    for (let i = 0; i < lens.length; i++) {
      starts.push(acc);
      acc += lens[i] + 1;
    }
    return { lineStarts: starts, lineLens: lens, total: acc };
  }, []);

  const [count, setCount] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setCount((c) => (c >= total ? c : c + 1));
    }, 32);
    return () => clearInterval(id);
  }, [total]);

  let activeIndex = 0;
  for (let i = 0; i < lineStarts.length; i++) {
    if (count >= lineStarts[i]) activeIndex = i;
  }

  return (
    <div className="w-full max-w-lg overflow-hidden rounded-2xl border border-cyan-500/20 bg-slate-950/80 shadow-[0_0_60px_rgba(34,211,238,0.15)] backdrop-blur-xl">
      <div className="flex items-center gap-2 border-b border-white/5 bg-slate-900/60 px-4 py-3">
        <span className="h-3 w-3 rounded-full bg-red-400/80" />
        <span className="h-3 w-3 rounded-full bg-yellow-400/80" />
        <span className="h-3 w-3 rounded-full bg-green-400/80" />
        <span className="ml-3 font-mono text-xs text-slate-400">
          OrderEnrichment.groovy
        </span>
        <span className="ml-auto rounded-md border border-cyan-500/20 bg-cyan-500/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-cyan-300">
          SAP CPI
        </span>
      </div>

      <div className="min-h-[230px] overflow-x-auto px-4 py-4 font-mono text-xs leading-relaxed">
        {codeLines.map((line, i) => {
          if (count < lineStarts[i]) return null;

          let budget = Math.max(
            0,
            Math.min(count, lineStarts[i] + lineLens[i]) - lineStarts[i]
          );

          return (
            <div key={i} className="flex whitespace-pre">
              <span className="mr-5 w-5 select-none text-right text-slate-700">
                {i + 1}
              </span>
              <span>
                {line.length === 0 ? (
                  <span>&nbsp;</span>
                ) : (
                  line.map((seg, j) => {
                    if (budget <= 0) return null;
                    const shown = seg.t.slice(0, budget);
                    budget -= shown.length;
                    return (
                      <span key={j} className={seg.c ?? "text-slate-200"}>
                        {shown}
                      </span>
                    );
                  })
                )}
                {i === activeIndex && (
                  <span className="ml-0.5 inline-block h-4 w-2 translate-y-[2px] animate-pulse bg-cyan-400" />
                )}
              </span>
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between border-t border-white/5 bg-slate-900/60 px-4 py-2.5 font-mono text-[11px] text-slate-500">
        <span className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
          Deployed to SAP Integration Suite
        </span>
        <span>UTF-8 · LF</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Small status pill                                                  */
/* ------------------------------------------------------------------ */
function Pill({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-slate-900/60 px-4 py-1.5 text-xs font-medium text-slate-300 backdrop-blur">
      {children}
    </span>
  );
}

export default function Hero() {
  return (
    <section className="relative min-h-screen overflow-hidden bg-[#030712] pt-24">
      {/* Background Grid */}
      <div
        className="
          absolute inset-0 opacity-[0.05]
          [background-image:linear-gradient(rgba(34,211,238,0.15)_1px,transparent_1px),linear-gradient(to_right,rgba(34,211,238,0.15)_1px,transparent_1px)]
          [background-size:70px_70px]
        "
      />

      {/* Glows */}
      <div className="absolute left-1/2 top-1/2 h-[900px] w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/5 blur-[180px]" />
      <div className="absolute -left-40 top-20 h-[600px] w-[600px] rounded-full bg-cyan-500/10 blur-[180px]" />
      <div className="absolute -right-40 bottom-0 h-[600px] w-[600px] rounded-full bg-blue-500/10 blur-[180px]" />

      <Container>
        <div className="relative z-10 grid min-h-[80vh] items-center gap-12 py-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-12">

          {/* ---------------- Left ---------------- */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Status pill */}
            {personal.available && (
              <Pill>
                <span className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
                Available for opportunities
              </Pill>
            )}

            {/* Name */}
            <h1 className="mt-7 text-6xl font-black leading-[1.05] md:text-8xl">
              <span className="block text-white">Bhairav</span>
              <span className="block bg-gradient-to-r from-cyan-300 via-cyan-400 to-sky-500 bg-clip-text pb-3 text-transparent">
                Singh
              </span>
            </h1>

            {/* Role */}
            <div className="mt-5 flex items-center gap-3 text-slate-300">
              <span className="h-px w-8 bg-cyan-400/60" />
              <span className="text-sm font-semibold uppercase tracking-[0.2em]">
                SAP Integration Developer
              </span>
            </div>

            {/* Typing line */}
            <div className="mt-6 h-8">
              <TypingText />
            </div>

            {/* Headline */}
            <h2 className="mt-8 max-w-xl text-2xl font-bold leading-snug text-white md:text-3xl">
              {personal.headline}
            </h2>

            {/* Description */}
            <p className="mt-7 max-w-xl text-base leading-7 text-slate-400">
              {personal.tagline}
            </p>

            {/* Buttons */}
            <div className="mt-10 flex flex-wrap items-center gap-4">
              <Button href="#projects">
                <span className="inline-flex items-center gap-2">
                  View Projects <ArrowRight size={16} />
                </span>
              </Button>
              <Button href={personal.resume} variant="secondary">
                <span className="inline-flex items-center gap-2">
                  <Download size={16} /> Download Resume
                </span>
              </Button>
            </div>
          </motion.div>

          {/* ---------------- Right ---------------- */}
          <motion.div
            initial={{ opacity: 0, x: 80 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col items-center"
          >
            {/* Slow floating illustration */}
            <motion.div
              animate={{ y: [0, -14, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="flex w-full flex-col items-center"
            >
              {/* Avatar */}
              <div className="relative flex h-[185px] w-[185px] items-center justify-center">
                {/* Ambient glow */}
                <div className="absolute inset-0 rounded-full bg-cyan-500/20 blur-3xl" />

                {/* Static base ring */}
                <div className="absolute inset-0 rounded-full border border-cyan-400/15" />

                {/* Moving line orbiting BH */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
                  className="absolute -inset-1 rounded-full border-2 border-transparent border-t-cyan-400 border-r-cyan-400/30"
                />

                {/* Avatar core (monogram — drop in a photo any time) */}
                <div className="absolute inset-[6px] flex items-center justify-center overflow-hidden rounded-full border border-cyan-400/10 bg-slate-950">
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-transparent to-blue-500/10" />
                  <div className="absolute inset-0 opacity-[0.12] [background-image:linear-gradient(rgba(34,211,238,0.5)_1px,transparent_1px),linear-gradient(to_right,rgba(34,211,238,0.5)_1px,transparent_1px)] [background-size:24px_24px]" />
                  <span className="relative text-6xl font-black text-cyan-400">
                    {personal.shortName}
                  </span>
                </div>
              </div>

              {/* Caption chip */}
              <div className="mt-5 rounded-full border border-cyan-400/20 bg-slate-900 px-4 py-1.5 text-xs font-medium tracking-wide text-cyan-300 shadow-lg">
                SAP Integration Developer
              </div>

              {/* Animated data-flow connector */}
              <div className="relative my-4 h-6 w-px overflow-hidden bg-gradient-to-b from-cyan-400/50 to-cyan-400/5">
                <motion.span
                  animate={{ y: [-6, 24], opacity: [0, 1, 0] }}
                  transition={{ duration: 1.4, repeat: Infinity, ease: "easeIn" }}
                  className="absolute left-1/2 top-0 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.9)]"
                />
              </div>

              {/* Terminal */}
              <CodeTerminal />
            </motion.div>
          </motion.div>
        </div>
      </Container>
    </section>
  );
}
